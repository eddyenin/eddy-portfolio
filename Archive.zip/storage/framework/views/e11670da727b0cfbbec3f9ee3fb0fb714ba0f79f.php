<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <section class="projects">
            <div class="head-in">
                <h3>Projects</h3>
                <p>Sample of some projects featured in and developed by myself</p>
            </div>
            <?php if(!empty($projects)): ?>
            <div class="row">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                   
                    <div class="card">
                        <div class="card-body">
                            <img src="<?php echo e(asset('/images/' . $project->image)); ?>" alt="">
                        </div>
                        <div class="card-footer">
                            <h4><?php echo e(ucfirst($project->title)); ?></h4>
                            <span><a href="<?php echo e($project->link); ?>"><?php echo e($project->link); ?></a></span>
                        </div>
                    </div>
                   
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <p>No projects yet</p>
                            <a href="<?php echo e(url('/')); ?>">Back</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </section>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.partials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abassoyong/Documents/eddy-project/resources/views/project/index.blade.php ENDPATH**/ ?>