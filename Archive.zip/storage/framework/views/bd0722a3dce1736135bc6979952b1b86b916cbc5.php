<nav class="navbar bg-light">
    <div class="container-fluid">
       <a href=" <?php echo e(url('/admin')); ?> "><span class="navbar-brand mb-0 h1">Eddy</span></a> 
        <ul class="d-flex admin-nav">
            <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(url('/admin/login')); ?>"> Login</a></li>
            <li><a href="<?php echo e(url('/admin/register')); ?>"> Register</a></li>
        </ul>
    </div>
</nav><?php /**PATH /Users/abassoyong/Documents/eddy-project/resources/views/components/nav.blade.php ENDPATH**/ ?>