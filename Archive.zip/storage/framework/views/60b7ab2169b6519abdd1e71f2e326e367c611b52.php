<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
                <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(url('/home/create')); ?>" class="btn btn-md btn-secondary">Add project</a>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Link</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                
                            </thead>
        
                            <tbody>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(ucfirst( $project->title)); ?></td>
                                    <td><a href="<?php echo e($project->link); ?>" target="_blank"><?php echo e($project->link); ?></a></td>
                                    <td>
                                        <img src="<?php echo e(asset('/images/' . $project->image )); ?>" width="100px" alt="">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('/home/edit/' . $project->id )); ?>" class="btn btn-sm btn-secondary">edit</a>  
                                        <form method="POST"  action="<?php echo e(url('/home/destroy/' . $project->id)); ?>">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                         <button type="submit"  class="btn btn-sm btn-danger"> Delete</button>
                                        </form>

            
                                    </td>
        
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abassoyong/Documents/eddy-project/resources/views/admin/projects.blade.php ENDPATH**/ ?>