<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h3>Edit project</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/home/update/'. $project->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <input type="text" name="title" class="form-control" value="<?php echo e($project->title); ?>" placeholder="Title" id="">
                            </div>
                            <br>
                            <div class="form-group">
                                <input type="text" name="link" class="form-control" value="<?php echo e($project->link); ?>" placeholder="Project link" id="">
                            </div>
                            <br>
                            <div class="form-group">
                                <input type="file" name="image" class="form-control" placeholder="Image" id="">
                            </div>
                            <br>
                            <div class="form-group">
                                <a href="<?php echo e(url('/home/projects')); ?>" class="btn btn-md btn-secondary">Back</a>
                                <button class="btn btn-md btn-secondary" type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
               
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abassoyong/Documents/eddy-project/resources/views/admin/edit.blade.php ENDPATH**/ ?>