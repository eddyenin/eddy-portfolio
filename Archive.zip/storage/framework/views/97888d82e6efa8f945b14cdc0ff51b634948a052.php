<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" class="form-control"  id="" placeholder="Username">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control" id="" placeholder="Password">
                </div>

                <div class="form-group">
                    <button class="btn btn-md btn-secondary" class="form-control" type="submit">login</button>
                </div>

            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.partials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abassoyong/Documents/eddy-project/resources/views/admin/login.blade.php ENDPATH**/ ?>